This font is made by Levi and may be used free of charge for non-commercial projects.  Please contact me if you plan to use it for other purposes. It also may be distributed free of charge on any websites provided this file is intact.
Contact:
url: http://www.geocities.com/noimage_2001/
email: halmoslevi@yahoo.com
